document.body.addEventListener('keypress',(e)=>{
    switch(e.key){
        case "a":
        let aClap = document.querySelector('#aClap');
        aClap.currentTime =0 ;
        aClap.play();

        if(isRecording1){
            listaCzasow1.push( Date.now() - czasTerazniejszy1) ; // zapamietanie kiedy dziwke nagrany
            listaDzwiekow1.push('#aClap'); // jaki dzwiek nagray xD
            
           }

           if(isRecording2){
            listaCzasow2.push( Date.now() - czasTerazniejszy2) ; // zapamietanie kiedy dziwke nagrany
            listaDzwiekow2.push('#aClap'); // jaki dzwiek nagray xDDDDD
            // nnagranie pojedynczego dzwieku
        }
        
        if(isRecording3){
            listaCzasow3.push( Date.now() - czasTerazniejszy3) ; // zapamietanie kiedy dziwke nagrany
            listaDzwiekow3.push('#aClap'); // jaki dzwiek nagray xDDDDD
            // nnagranie pojedynczego dzwieku
        }
        
        if(isRecording4){
            listaCzasow4.push( Date.now() - czasTerazniejszy4) ; // zapamietanie kiedy dziwke nagrany
            listaDzwiekow4.push('#aClap'); // jaki dzwiek nagray xDDDDD
            // nnagranie pojedynczego dzwieku
        } 

        break;


        case "s":
        let sClap = document.querySelector('#sClap');
        sClap.currentTime =0 ;
        sClap.play();

        if(isRecording1){
            listaCzasow1.push( Date.now() - czasTerazniejszy1) ; // zapamietanie kiedy dziwke nagrany
            listaDzwiekow1.push('#sClap'); // jaki dzwiek nagray xD
        }
        

        if(isRecording2){
            listaCzasow2.push( Date.now() - czasTerazniejszy2) ; // zapamietanie kiedy dziwke nagrany
            listaDzwiekow2.push('#sClap'); // jaki dzwiek nagray xDDDDD
            // nnagranie pojedynczego dzwieku
        }

        if(isRecording3){
            listaCzasow3.push( Date.now() - czasTerazniejszy3) ; // zapamietanie kiedy dziwke nagrany
            listaDzwiekow3.push('#sClap'); // jaki dzwiek nagray xDDDDD
            // nnagranie pojedynczego dzwieku
        }

        if(isRecording4){
            listaCzasow4.push( Date.now() - czasTerazniejszy4) ; // zapamietanie kiedy dziwke nagrany
            listaDzwiekow4.push('#sClap'); // jaki dzwiek nagray xDDDDD
            // nnagranie pojedynczego dzwieku
        }  
        break;

        case "d":
        let dClap = document.querySelector('#dClap');
        dClap.currentTime =0 ;
        dClap.play();
        if(isRecording1){
            listaCzasow1.push( Date.now() - czasTerazniejszy1) ; // zapamietanie kiedy dziwke nagrany
            listaDzwiekow1.push('#dClap'); // jaki dzwiek nagray xD
        }

        if(isRecording2){
            listaCzasow2.push( Date.now() - czasTerazniejszy2) ; // zapamietanie kiedy dziwke nagrany
            listaDzwiekow2.push('#dClap'); // jaki dzwiek nagray xDDDDD
            // nnagranie pojedynczego dzwieku
        }
    
        if(isRecording3){
            listaCzasow3.push( Date.now() - czasTerazniejszy3) ; // zapamietanie kiedy dziwke nagrany
            listaDzwiekow3.push('#dClap'); // jaki dzwiek nagray xDDDDD
            // nnagranie pojedynczego dzwieku
        }
    
        if(isRecording4){
            listaCzasow4.push( Date.now() - czasTerazniejszy4) ; // zapamietanie kiedy dziwke nagrany
            listaDzwiekow4.push('#dClap'); // jaki dzwiek nagray xDDDDD
            // nnagranie pojedynczego dzwieku
        } 
        break;

        case "f":
        let fClap = document.querySelector('#fClap');
        fClap.currentTime =0 ;
        fClap.play();

        if(isRecording1){
            listaCzasow1.push( Date.now() - czasTerazniejszy1) ; // zapamietanie kiedy dziwke nagrany
            listaDzwiekow1.push('#fClap'); // jaki dzwiek nagray xD
            
        }

        if(isRecording2){
            listaCzasow2.push( Date.now() - czasTerazniejszy2) ; // zapamietanie kiedy dziwke nagrany
            listaDzwiekow2.push('#fClap'); // jaki dzwiek nagray xDDDDD
            // nnagranie pojedynczego dzwieku
        }
    
        if(isRecording3){
            listaCzasow3.push( Date.now() - czasTerazniejszy3) ; // zapamietanie kiedy dziwke nagrany
            listaDzwiekow3.push('#fClap'); // jaki dzwiek nagray xDDDDD
            // nnagranie pojedynczego dzwieku
        }
    
        if(isRecording4){
            listaCzasow4.push( Date.now() - czasTerazniejszy4) ; // zapamietanie kiedy dziwke nagrany
            listaDzwiekow4.push('#fClap'); // jaki dzwiek nagray xDDDDD
            // nnagranie pojedynczego dzwieku
        } 
        break;


        case "z":
        let zClap = document.querySelector('#zClap');
        zClap.currentTime =0 ;
        zClap.play();

        if(isRecording1){
            listaCzasow1.push( Date.now() - czasTerazniejszy1) ; // zapamietanie kiedy dziwke nagrany
            listaDzwiekow1.push('#zClap'); // jaki dzwiek nagray xD
            
        }

        if(isRecording2){
            listaCzasow2.push( Date.now() - czasTerazniejszy2) ; // zapamietanie kiedy dziwke nagrany
            listaDzwiekow2.push('#zClap'); // jaki dzwiek nagray xDDDDD
            // nnagranie pojedynczego dzwieku
        }
    
        if(isRecording3){
            listaCzasow3.push( Date.now() - czasTerazniejszy3) ; // zapamietanie kiedy dziwke nagrany
            listaDzwiekow3.push('#zClap'); // jaki dzwiek nagray xDDDDD
            // nnagranie pojedynczego dzwieku
        }
    
        if(isRecording4){
            listaCzasow4.push( Date.now() - czasTerazniejszy4) ; // zapamietanie kiedy dziwke nagrany
            listaDzwiekow4.push('#zClap'); // jaki dzwiek nagray xDDDDD
            // nnagranie pojedynczego dzwieku
        } 
        break;

        case "x":
        let xClap = document.querySelector('#xClap');
        xClap.currentTime =0 ;
        xClap.play();

        if(isRecording1){
            listaCzasow1.push( Date.now() - czasTerazniejszy1) ; // zapamietanie kiedy dziwke nagrany
            listaDzwiekow1.push('#xClap'); // jaki dzwiek nagray xD
            
        }
 
        if(isRecording2){
            listaCzasow2.push( Date.now() - czasTerazniejszy2) ; // zapamietanie kiedy dziwke nagrany
            listaDzwiekow2.push('#xClap'); // jaki dzwiek nagray xDDDDD
            // nnagranie pojedynczego dzwieku
        }

        if(isRecording3){
            listaCzasow3.push( Date.now() - czasTerazniejszy3) ; // zapamietanie kiedy dziwke nagrany
            listaDzwiekow3.push('#xClap'); // jaki dzwiek nagray xDDDDD
            // nnagranie pojedynczego dzwieku
        }

        if(isRecording4){
            listaCzasow4.push( Date.now() - czasTerazniejszy4) ; // zapamietanie kiedy dziwke nagrany
            listaDzwiekow4.push('#xClap'); // jaki dzwiek nagray xDDDDD
            // nnagranie pojedynczego dzwieku
        } 
        break;
    }
})

//klikanie myszka na litery
document.querySelector('#aprzycisk').addEventListener("mousedown",(e)=>{
   let aClap = document.querySelector('#aClap');
   aClap.currentTime = 0;
   aClap.play();

   if(isRecording1){
        listaCzasow1.push( Date.now() - czasTerazniejszy1) ; // zapamietanie kiedy dziwke nagrany
        listaDzwiekow1.push('#aClap'); // jaki dzwiek nagray xDDDDD
    // nnagranie pojedynczego dzwieku
   }
   

   if(isRecording2){
    listaCzasow2.push( Date.now() - czasTerazniejszy2) ; // zapamietanie kiedy dziwke nagrany
    listaDzwiekow2.push('#aClap'); // jaki dzwiek nagray xDDDDD
    // nnagranie pojedynczego dzwieku
}

if(isRecording3){
    listaCzasow3.push( Date.now() - czasTerazniejszy3) ; // zapamietanie kiedy dziwke nagrany
    listaDzwiekow3.push('#aClap'); // jaki dzwiek nagray xDDDDD
    // nnagranie pojedynczego dzwieku
}

if(isRecording4){
    listaCzasow4.push( Date.now() - czasTerazniejszy4) ; // zapamietanie kiedy dziwke nagrany
    listaDzwiekow4.push('#aClap'); // jaki dzwiek nagray xDDDDD
    // nnagranie pojedynczego dzwieku
} 
})

document.querySelector('#dprzycisk').addEventListener("mousedown",(e)=>{
    let dClap = document.querySelector('#dClap');
    dClap.currentTime = 0;
    dClap.play();

    if(isRecording1){
        listaCzasow1.push( Date.now() - czasTerazniejszy1) ; // zapamietanie kiedy dziwke nagrany
        listaDzwiekow1.push('#dClap'); // jaki dzwiek nagray xDDDDD
        // nnagranie pojedynczego dzwieku
    }
    

    if(isRecording2){
        listaCzasow2.push( Date.now() - czasTerazniejszy2) ; // zapamietanie kiedy dziwke nagrany
        listaDzwiekow2.push('#dClap'); // jaki dzwiek nagray xDDDDD
        // nnagranie pojedynczego dzwieku
    }

    if(isRecording3){
        listaCzasow3.push( Date.now() - czasTerazniejszy3) ; // zapamietanie kiedy dziwke nagrany
        listaDzwiekow3.push('#dClap'); // jaki dzwiek nagray xDDDDD
        // nnagranie pojedynczego dzwieku
    }

    if(isRecording4){
        listaCzasow4.push( Date.now() - czasTerazniejszy4) ; // zapamietanie kiedy dziwke nagrany
        listaDzwiekow4.push('#dClap'); // jaki dzwiek nagray xDDDDD
        // nnagranie pojedynczego dzwieku
    } 
})

document.querySelector('#fprzycisk').addEventListener("mousedown",(e)=>{
    let fClap = document.querySelector('#fClap');
    fClap.currentTime = 0;
    fClap.play();

    if(isRecording1){
        listaCzasow1.push( Date.now() - czasTerazniejszy1) ; // zapamietanie kiedy dziwke nagrany
        listaDzwiekow1.push('#fClap'); // jaki dzwiek nagray xDDDDD
        // nnagranie pojedynczego dzwieku
    }
    

    if(isRecording2){
        listaCzasow2.push( Date.now() - czasTerazniejszy2) ; // zapamietanie kiedy dziwke nagrany
        listaDzwiekow2.push('#fClap'); // jaki dzwiek nagray xDDDDD
        // nnagranie pojedynczego dzwieku
    }

    if(isRecording3){
        listaCzasow3.push( Date.now() - czasTerazniejszy3) ; // zapamietanie kiedy dziwke nagrany
        listaDzwiekow3.push('#fClap'); // jaki dzwiek nagray xDDDDD
        // nnagranie pojedynczego dzwieku
    }

    if(isRecording4){
        listaCzasow4.push( Date.now() - czasTerazniejszy4) ; // zapamietanie kiedy dziwke nagrany
        listaDzwiekow4.push('#fClap'); // jaki dzwiek nagray xDDDDD
        // nnagranie pojedynczego dzwieku
    } 
})

document.querySelector('#zprzycisk').addEventListener("mousedown",(e)=>{
    let zClap = document.querySelector('#zClap');
    zClap.currentTime = 0;
    zClap.play();

    if(isRecording1){
        listaCzasow1.push( Date.now() - czasTerazniejszy1) ; // zapamietanie kiedy dziwke nagrany
        listaDzwiekow1.push('#zClap'); // jaki dzwiek nagray xDDDDD
        // nnagranie pojedynczego dzwieku
    }
    
    if(isRecording2){
        listaCzasow2.push( Date.now() - czasTerazniejszy2) ; // zapamietanie kiedy dziwke nagrany
        listaDzwiekow2.push('#zClap'); // jaki dzwiek nagray xDDDDD
        // nnagranie pojedynczego dzwieku
    }

    if(isRecording3){
        listaCzasow3.push( Date.now() - czasTerazniejszy3) ; // zapamietanie kiedy dziwke nagrany
        listaDzwiekow3.push('#zClap'); // jaki dzwiek nagray xDDDDD
        // nnagranie pojedynczego dzwieku
    }

    if(isRecording4){
        listaCzasow4.push( Date.now() - czasTerazniejszy4) ; // zapamietanie kiedy dziwke nagrany
        listaDzwiekow4.push('#zClap'); // jaki dzwiek nagray xDDDDD
        // nnagranie pojedynczego dzwieku
    } 
})

document.querySelector('#xprzycisk').addEventListener("mousedown",(e)=>{
    let xClap = document.querySelector('#xClap');
    xClap.currentTime = 0;
    xClap.play();

    if(isRecording1){
        listaCzasow1.push( Date.now() - czasTerazniejszy1) ; // zapamietanie kiedy dziwke nagrany
        listaDzwiekow1.push('#xClap'); // jaki dzwiek nagray xDDDDD
        // nnagranie pojedynczego dzwieku
    }

    if(isRecording2){
        listaCzasow2.push( Date.now() - czasTerazniejszy2) ; // zapamietanie kiedy dziwke nagrany
        listaDzwiekow2.push('#xClap'); // jaki dzwiek nagray xDDDDD
        // nnagranie pojedynczego dzwieku
    }

    if(isRecording3){
        listaCzasow3.push( Date.now() - czasTerazniejszy3) ; // zapamietanie kiedy dziwke nagrany
        listaDzwiekow3.push('#xClap'); // jaki dzwiek nagray xDDDDD
        // nnagranie pojedynczego dzwieku
    }

    if(isRecording4){
        listaCzasow4.push( Date.now() - czasTerazniejszy4) ; // zapamietanie kiedy dziwke nagrany
        listaDzwiekow4.push('#xClap'); // jaki dzwiek nagray xDDDDD
        // nnagranie pojedynczego dzwieku
    } 
})
document.querySelector('#sprzycisk').addEventListener("mousedown",(e)=>{
    let sClap = document.querySelector('#sClap');
    sClap.currentTime = 0;
    sClap.play();

    if(isRecording1){
        listaCzasow1.push( Date.now() - czasTerazniejszy1) ; // zapamietanie kiedy dziwke nagrany
        listaDzwiekow1.push('#sClap'); // jaki dzwiek nagray xDDDDD
        // nnagranie pojedynczego dzwieku
    }

    if(isRecording2){
        listaCzasow2.push( Date.now() - czasTerazniejszy2) ; // zapamietanie kiedy dziwke nagrany
        listaDzwiekow2.push('#sClap'); // jaki dzwiek nagray xDDDDD
        // nnagranie pojedynczego dzwieku
    }

    if(isRecording3){
        listaCzasow3.push( Date.now() - czasTerazniejszy3) ; // zapamietanie kiedy dziwke nagrany
        listaDzwiekow3.push('#sClap'); // jaki dzwiek nagray xDDDDD
        // nnagranie pojedynczego dzwieku
    }

    if(isRecording4){
        listaCzasow4.push( Date.now() - czasTerazniejszy4) ; // zapamietanie kiedy dziwke nagrany
        listaDzwiekow4.push('#sClap'); // jaki dzwiek nagray xDDDDD
        // nnagranie pojedynczego dzwieku
    }  
       
})


// zapisywanie dzwieku 
var czasTerazniejszy1;
var listaCzasow1 = [];
var listaDzwiekow1 = [];
var isRecording1 = false; // domyslnie nie nagrywa XD

document.querySelector('#pRecord1').addEventListener("mousedown",(e)=>{
    if(!isRecording1){
        czasTerazniejszy1 = Date.now();
        listaCzasow1 = [];
        listaDzwiekow1 = [];
        isRecording1 = true;
        document.querySelector('#pRecord1').innerHTML = "Stop";
    }
    else{
        isRecording1 = false;
        document.querySelector('#pRecord1').innerHTML = "Record";
    }
})

document.querySelector('#pPlay1').addEventListener("mousedown",(e)=>{
    for (let i = 0; i<listaDzwiekow1.length;i++){
        setTimeout(()=>{
            document.querySelector(listaDzwiekow1[i]).currentTime = 0; // rozpoczynanie "od nowa":)
            document.querySelector(listaDzwiekow1[i]).play(); 
        },listaCzasow1[i])//opoznienie
    }


    
})

var czasTerazniejszy2;
var listaCzasow2 = [];
var listaDzwiekow2 = [];
var isRecording2 = false; // domyslnie nie nagrywa XD

document.querySelector('#pRecord2').addEventListener("mousedown",(e)=>{
    if(!isRecording2){
        czasTerazniejszy2 = Date.now();
        listaCzasow2 = [];
        listaDzwiekow2 = [];
        isRecording2 = true;
        document.querySelector('#pRecord2').innerHTML = "Stop";
    }
    else{
        isRecording2 = false;
        document.querySelector('#pRecord2').innerHTML = "Record";
    }
})

document.querySelector('#pPlay2').addEventListener("mousedown",(e)=>{
    for (let i = 0; i<listaDzwiekow2.length;i++){
        setTimeout(()=>{
            document.querySelector(listaDzwiekow2[i]).currentTime = 0; // rozpoczynanie "od nowa":)
            document.querySelector(listaDzwiekow2[i]).play(); 
        },listaCzasow2[i])//opoznienie
    }
})
