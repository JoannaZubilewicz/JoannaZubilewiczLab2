class Notatka {
    constructor(tytul,tresc,kolorNotatki,przypieta,utworzono,top,left){
        this.tytul = tytul;
        this.tresc = tresc;
        this.kolorNotatki = kolorNotatki;
        this.przypieta= przypieta;
        this.utworzono= utworzono;
        this.top= top;
        this.left=left;
    }
}

let Notatki = [];



function createNote(notatkaBody){
    if(notatkaBody == undefined){
        notatkaBody = new Notatka(
            "",
            "",
            "#3A005C",
            false,
            Date.now(),
            0,
            0
        )
        Notatki.push(notatkaBody);
    }


    let dragged = false;

    let notatka = document.createElement("div");
    
    notatka.classList.add("notatka");
    let pasek = document.createElement("div");
    pasek.classList.add("pasek");
    // poruszanie notatka
    pasek.addEventListener("mousedown",function(){
        dragged = true;
    })
    pasek.addEventListener("mouseup",function(){
        dragged = false;
    })
    pasek.addEventListener("mouseleave",function(){
        dragged = false;
    })
    pasek.addEventListener("mousemove",function(e){
        if(!dragged) return;

        let top = window.getComputedStyle(notatka).top; // z jakiego elementu style czyli tutaj z notatek
        let left = window.getComputedStyle(notatka).left;
        top = Number(top.split("p")[0]);
        left = Number(left.split("p")[0]);

        notatka.style.left = left+e.movementX+ "px";
        notatka.style.top = top+e.movementY+ "px";

        Notatki[notatka.tag].top = top+e.movementY;
        Notatki[notatka.tag ].left = left+e.movementX;

    })

    let text = document.createElement("input");
    text.type = "text";
    text.classList.add("tytul");
    text.placeholder = "Tytuł...";
    text.value = notatkaBody.tytul;
    let img1 = document.createElement("img");
    img1.src = "img/push-pin.png";
    img1.classList.add("pinezka");
    
    let color = document.createElement("input");
    color.type = "color";
    color.classList.add("kolorki");
    color.value = notatkaBody.color;

    let usunNotke = document.createElement("div");
    usunNotke.classList.add("usunNotke");
    usunNotke.addEventListener("mousedown", function(e){
        console.log(e.target.parentElement.parentElement.parentElement)
        document.body.removeChild(e.target.parentElement.parentElement.parentElement);
    })

    let img2 = document.createElement("img");
    img2.src = "img/stand-by.png";

    let zawartoscNotatki = document.createElement("textarea");
    zawartoscNotatki.classList.add("zawartoscNotatki");
    zawartoscNotatki.value = notatkaBody.tresc;

    let lastModified = document.createElement("div");
    lastModified.classList.add("lastModified");

    let p = document.createElement("p");
    p.innerHTML = "utworzono: " + (new Date(notatkaBody.utworzono)).toLocaleString();




    usunNotke.appendChild(img2);
    pasek.appendChild(text); // do paska text
    pasek.appendChild(img1);
    pasek.appendChild(color);
    pasek.appendChild(usunNotke);
    notatka.appendChild(pasek);// do notatki dodaje pasek
    notatka.appendChild(zawartoscNotatki);
    lastModified.appendChild(p);
    notatka.appendChild(lastModified);
    document.body.appendChild(notatka);// do documentu-body dodaje notke XD
    
}